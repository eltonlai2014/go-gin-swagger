/**
 * @prettier
 */
const regexGenerator = () => "^[a-z]+$"

export default regexGenerator
